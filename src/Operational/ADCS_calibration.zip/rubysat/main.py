import sys
import time
import datetime
from command_handler import CommandHandler # Custom module for handling commands
import os
from client.rubySatClient import Client # Custom  module for communication with the Manager computer
import datetime
import queue
import socket
import random
import struct
import json
import threading
import traceback
import subprocess


def is_daemon_running(process_name="daemon_server.py"):
    # Use tasklist on Windows to check if the process is running
    try:
        result = subprocess.run(
            ["tasklist"], stdout=subprocess.PIPE, text=True, shell=True
        )
        return process_name in result.stdout
    except Exception as e:
        print(f"Error checking process: {e}")
        return False


def start_daemon_server():
    if is_daemon_running():
        print("Daemon server is already running.")
        return
    try:
        # Command to activate the environment and start daemon_server.py
        subprocess.Popen(
            [
                "cmd.exe", "/k", 
                "conda activate env && cd C:\\Users\\SatUser\\Desktop\\RubySat\\rubysat && python daemon_server.py"
            ],
            shell=True
        )
        print("Daemon server started successfully.")
    except Exception as e:
        print(f"Failed to start daemon server: {e}")
        

def to_unix_time(time_fmt):
    # Converts a time tuple to Unix timestamp format
    time_fmt = tuple(time_fmt)
    year, month, day, hour, minute, float_seconds = time_fmt
    dt = datetime.datetime(year, month, day, hour, minute, int(float_seconds))
    dt = dt + datetime.timedelta(seconds=float_seconds - int(float_seconds))
    return dt.replace(tzinfo=datetime.timezone.utc).timestamp()


class DataFromCosmos:
    def __init__(self, host, port):
        # Initialize the socket and queue for receiving data from Cosmos
        self.queue = queue.Queue()
        self.ruby_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.ruby_addr = (host, port)
        self._stop_event = threading.Event()
        
    @property
    def last_message(self):
        # Retrieves the last message in the queue if available, else returns False
        return self.queue.get() if not self.queue.empty() else False

    def recv_all(self, n):
        """ Helper function to ensure all 'n' bytes are received """
        data = bytearray()
        while len(data) < n:
            packet = self.ruby_socket.recv(n - len(data))
            if not packet:
                return None
            data.extend(packet)
        return data

    def run(self):
        # Connects to the Cosmos server and continuously receives data
        print("waiting")
        print(self.ruby_addr)
        self.ruby_socket.connect(self.ruby_addr)
        print("Connected")
        while True:
            packed_length = self.ruby_socket.recv(4) # Receive the length of the incoming JSON data
            
            if not packed_length:
                return None
            length = struct.unpack('!I', packed_length)[0] # Unpack the length
            json_data = self.ruby_socket.recv(length) # Receive the actual JSON data
            if not json_data:
                return None
            data = json.loads(json_data.decode('utf-8'))
            self.queue.put(data)
            
            # print the command which has been recieved
            #print(f"Data which entered Queue: {data.keys()}") # Check which commands or data is being inserted to the queue...
            
    def stop(self):
        self._stop_event.set()

            
        


if __name__ == '__main__':
    # Start the daemon server
    #start_daemon_server()
    # Main execution block
    commands_file_name = "commands.yml" # YAML file with commands
    simulation_duration = 60 * 90 # Duration of the simulation in seconds
    simulation_text_file = "simulationRelativeTime.txt" # Output file for simulation script
    current_time = int(time.time()) # Get the current time
    com_channel = "ESAT10_WIFI" # Communication channel with the satellite

    # Remove existing simulation file if it exists
    if os.path.exists(simulation_text_file):
        os.remove(simulation_text_file)

    # Initialize command handler with command file and communication channel
    handler = CommandHandler(commands_file_name, com_channel)  

    # Exit if command file is invalid
    if not handler.valid_command_file:
        sys.exit(1)

    # Initialize client and connect to the Manager computer
    client = Client(sys.argv[1], 13020, "operational")
    client.run()
    
    # Prepare the client and get initial data for the simulation
    _, time_data, night_prob = client.prep()
    simulation_time_start = int(to_unix_time(time_data)) # Convert time data to Unix format
    
    # Set end time for simulation
    simulation_end_time = simulation_time_start + simulation_duration
    simulation_data = handler.simulate(simulation_duration)

    handler.write_simulation_file(simulation_text_file) # Write the simulation data and write it to a file
    handler.start_server() # Start connection with the Ruby script
    
    # Start a thread to receive data from Cosmos server 
    CosmosRecv = DataFromCosmos("127.0.0.1", 34567)
    CosmosRecv_thread = threading.Thread(target=CosmosRecv.run, daemon=False)
    CosmosRecv_thread.start()

    last_command = None # Variable to store the last command executed
    night_time = False  # Tracks if the current time is considered "night" for command execution rules
    
    
    try:
        # Loop through each command in the simulation dictionary and execute based on time
        for command_epoch_time, command in handler.simulation_dic.items():
            script_line = str(command_epoch_time) + " " + command
            handler.last_execution_line = script_line # Update the last executed line
            new_exe_msg = {}
            
            # Include the last executed command if available
            if last_command:
                new_exe_msg.update({"command": last_command})
                
            # Get the last message from Cosmos if available    
            last_cosmos_message = CosmosRecv.last_message
            if (last_cosmos_message):
                new_exe_msg.update({"cosmos_data": last_cosmos_message})
                
            # Execute the command and get execution data from the client    
            exe_data = client.execute(new_exe_msg)
            # Delete the two following print after
            # print(f"sended the new exe msg: {new_exe_msg}")
            # print(f"The response: {exe_data}")
                          
            night_time = night_time if exe_data.get("night_probability") is None else exe_data.get("night_probability")
            last_command = None

             # Calculate the current simulation time
            current_time = int(to_unix_time(exe_data["time"])) - simulation_time_start
            command_time, command = script_line.split(maxsplit=1)
            command_time = int(command_time)
            
            # Wait until it's time to execute the next command
            while command_time >= current_time:
                last_cosmos_message = CosmosRecv.last_message
                
                if (last_cosmos_message):
                    exe_data = client.execute({"cosmos_data": last_cosmos_message})
                    print(f"The cosmos message is: {last_cosmos_message}")
                else:
                    exe_data = client.execute({})
                    
                # Update night_time if needed and recalculate current time    
                night_time = night_time if exe_data.get("night_probability") is None else exe_data.get("night_probability")
                current_time = int(to_unix_time(exe_data["time"])) - simulation_time_start
                
                # Execute or skip command based on conditions
                if current_time == command_time:
                    last_command = command
                    if night_time:
                        # Randomly decide to execute or skip the command during night
                        if (random.randint(1, 100) < night_prob):
                            print(f"The command at time {current_time} is being executed...\n")
                            handler.run_command(current_time)
                            break
                        else:
                            print(f"The command at time {current_time} skipped\n")
                        break
                    else:
                        print(f"The command at time {current_time} is being executed...\n")
                        handler.run_command(current_time)
                        break
                    
        #Send the last command and cosmos data and the last command to the manager
        new_exe_msg = {}
        
        if last_command:
            new_exe_msg.update({"command": last_command})
            print(f"Added the last command to the new msg: {last_command}")
                
        # Get the last message from Cosmos if available    
        last_cosmos_message = CosmosRecv.last_message
        if (last_cosmos_message):
            new_exe_msg.update({"cosmos_data": last_cosmos_message})
                
            # Execute the command and get execution data from the client    
        exe_data = client.execute(new_exe_msg)
        print(f"Just sended the last msg, the message: {new_exe_msg}")
        print(f"The response: {exe_data}")
        
        # Wait until the simulation end time is reached           
        while current_time <= simulation_end_time:
            current_time += 1
            time.sleep(1)
           
    except TypeError as e:
        # Handle errors and print traceback for debugging
        print("An error occurred:", e)
        traceback.print_exc()  # This will print the full traceback
    finally:
        # Clean up by stopping all modules, server, and Cosmos receiving thread
        handler.stop_all_modules()
        handler.stop_server()
        CosmosRecv.stop()  
        CosmosRecv_thread.join()
        
