require 'socket'
require 'cosmos'
require 'cosmos/script'
require 'time'
require 'json'

def send_with_length(client, data)
  json_data = JSON.generate(data)
  length = json_data.bytesize
  packed_length = [length].pack("N")
  client.write(packed_length + json_data)
end

def fetch_packets
  {
    "TPL_PACKET" => get_tlm_packet("ESAT10_WIFI", "TPL_PACKET"),
    "PI_PAYLOAD_STATUS_PACKET" => get_tlm_packet("ESAT10_WIFI", "PI_PAYLOAD_STATUS_PACKET"),
    "EPS_PACKET" => get_tlm_packet("ESAT10_WIFI", "EPS_PACKET"),
    "OBC_PACKET" => get_tlm_packet("ESAT10_WIFI", "OBC_PACKET"),
    "OBC_PROCESSOR_PACKET" => get_tlm_packet("ESAT10_WIFI", "OBC_PROCESSOR_PACKET")
  }
end

server = TCPServer.new('localhost', 3456)
puts "Server is running on localhost:3456"

Signal.trap("INT") do
  puts "Shutting down server..."
  server.close
  exit
end

loop do
  begin
    client = server.accept
    puts "Client connected"

    packets = fetch_packets

    loop do
      send_with_length(client, packets)
      sleep(1)
    end
  rescue StandardError => e
    puts "Error during client connection: #{e.message}"
  ensure
    client.close if client
    puts "Client disconnected"
  end
end

puts "Server stopped..."
