require 'socket'
require 'cosmos/script'
require 'time'

server = TCPServer.new('127.0.0.1', 2345)
puts "Server is running on localhost:2345"

loop do
  begin
    client = server.accept
    puts "Client connected"
    message = client.gets
    if message
      message = message.strip
      puts "Received message: #{message}"
      puts Time.now.iso8601
      if message != "exit"
        cmd(message)
        puts Time.now.iso8601
        client.puts "Command executed"
      else
        client.puts "Exiting..."
        client.close
        break
      end
    else
      puts "Received an empty message"
    end

  rescue => e
    puts "Error during client connection: #{e.message}"
  ensure
    client.close if client
  end
end

puts "Server stopped..."
