import socket
import threading
import subprocess
from utils import receive_msgpack


HOST = '0.0.0.0'
PORT = 13022

def handle_client(connection):
    with connection:
        print('Connected by', connection.getpeername())
        while True:
            data = receive_msgpack(connection)
            print(data)
            if not data:
                break
            subprocess.Popen(["python", "main.py", data[1]], shell=True)

def start_daemon():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        while True:
            conn, addr = s.accept()
            threading.Thread(target=handle_client, args=(conn,)).start()

if __name__ == "__main__":
    start_daemon()